package com.example.tapas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@org.springframework.test.context.ActiveProfiles("demo")
@SpringBootTest
class TapasApplicationTests {

    @Test
    void contextLoads() {
    }

}
