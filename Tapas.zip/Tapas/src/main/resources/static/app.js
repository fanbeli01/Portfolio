// La pantalla usa la API Java. No guarda una copia de las tapas en el navegador.
const lista = document.getElementById("lista");
const estado = document.getElementById("estado");
const formulario = document.getElementById("formulario");
const nombre = document.getElementById("nombre");
const precio = document.getElementById("precio");
const tipo = document.getElementById("tipo");
const filtro = document.getElementById("filtro");
const guardar = document.getElementById("guardar");
const cancelar = document.getElementById("cancelar");
let idEnEdicion = null;
let numeroConsulta = 0;

function mostrarEstado(texto, error = false) {
    estado.textContent = texto;
    estado.classList.toggle("error", error);
}

async function llamarApi(ruta, opciones = {}) {
    const respuesta = await fetch("/api/tapas" + ruta, opciones);
    if (!respuesta.ok) {
        let mensaje = "No se pudo completar la operación (" + respuesta.status + ").";
        try {
            const detalle = await respuesta.json();
            if (detalle.message) mensaje = detalle.message;
        } catch (error) {
            // Algunos errores no incluyen un cuerpo JSON.
        }
        throw new Error(mensaje);
    }
    if (respuesta.status === 204) return null;
    return respuesta.json();
}

async function cargarTapas(mensaje = "Carta actualizada.") {
    // Solo dibujamos la última consulta si se cambia el filtro rápidamente.
    const consultaActual = ++numeroConsulta;
    try {
        const tapas = await llamarApi("?tipo=" + encodeURIComponent(filtro.value));
        if (consultaActual !== numeroConsulta) return;
        lista.replaceChildren();
        if (tapas.length === 0) {
            const vacio = document.createElement("p");
            vacio.textContent = "No hay tapas en esta selección. Añade una desde el formulario.";
            lista.appendChild(vacio);
        }
        for (const tapa of tapas) {
            mostrarTarjeta(tapa);
        }
        mostrarEstado(mensaje + " " + tapas.length + " tapas visibles.");
    } catch (error) {
        if (consultaActual === numeroConsulta) mostrarEstado(error.message, true);
    }
}

function mostrarTarjeta(tapa) {
    const tarjeta = document.createElement("article");
    tarjeta.className = "tarjeta";
    const etiqueta = document.createElement("span");
    etiqueta.className = "tipo";
    etiqueta.textContent = tapa.tipoTapas === "fria" ? "Tapa fría" : "Tapa caliente";
    const titulo = document.createElement("h3");
    titulo.textContent = tapa.nombre;
    const importe = document.createElement("p");
    importe.className = "precio";
    importe.textContent = Number(tapa.precio).toFixed(2).replace(".", ",") + " €";
    const acciones = document.createElement("div");
    acciones.className = "acciones";
    const editar = document.createElement("button");
    editar.textContent = "Editar";
    editar.addEventListener("click", function () {
        idEnEdicion = tapa.id;
        nombre.value = tapa.nombre;
        precio.value = tapa.precio;
        tipo.value = tapa.tipoTapas;
        document.getElementById("titulo-formulario").textContent = "Editar tapa";
        cancelar.hidden = false;
        nombre.focus();
    });
    const eliminar = document.createElement("button");
    eliminar.className = "secundario";
    eliminar.textContent = "Eliminar";
    eliminar.addEventListener("click", async function () {
        if (!confirm("¿Eliminar " + tapa.nombre + "?")) return;
        eliminar.disabled = true;
        try {
            await llamarApi("/" + tapa.id, { method: "DELETE" });
            if (idEnEdicion === tapa.id) limpiarFormulario();
            await cargarTapas("Tapa eliminada.");
        } catch (error) {
            mostrarEstado(error.message, true);
            eliminar.disabled = false;
        }
    });
    acciones.append(editar, eliminar);
    tarjeta.append(etiqueta, titulo, importe, acciones);
    lista.appendChild(tarjeta);
}

function limpiarFormulario() {
    formulario.reset();
    idEnEdicion = null;
    cancelar.hidden = true;
    document.getElementById("titulo-formulario").textContent = "Añadir una tapa";
}

formulario.addEventListener("submit", async function (evento) {
    evento.preventDefault();
    const tapa = { nombre: nombre.value.trim(), precio: Number(precio.value), tipoTapas: tipo.value };
    if (!tapa.nombre) {
        mostrarEstado("Escribe un nombre.", true);
        return;
    }
    guardar.disabled = true;
    try {
        const ruta = idEnEdicion === null ? "" : "/" + idEnEdicion;
        await llamarApi(ruta, {
            method: idEnEdicion === null ? "POST" : "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(tapa)
        });
        limpiarFormulario();
        await cargarTapas("Tapa guardada. Si no aparece, revisa el filtro.");
    } catch (error) {
        mostrarEstado(error.message, true);
    } finally {
        guardar.disabled = false;
    }
});
cancelar.addEventListener("click", limpiarFormulario);
filtro.addEventListener("change", function () { cargarTapas(); });
cargarTapas();
