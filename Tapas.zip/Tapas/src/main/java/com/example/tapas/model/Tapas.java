package com.example.tapas.model;

import jakarta.persistence .*;

@Entity
@Table(name = "Tapas")

public class Tapas {

            // --- CLAVE PRIMARIA (OBLIGATORIA) ---
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "id")
        private Long id;

        // --- COLUMNAS DE LA TABLA ---
        @Column(name = "Nombre")
        private String nombre;

        @Column(name = "Precio")
        private Double precio;

    @Column(name = "TipoTapas")
    private String tipoTapas;


        // --- 1. CONSTRUCTOR VACÍO (Obligatorio para JPA) ---
        public Tapas() {
        }


        // --- 2. CONSTRUCTOR CON DATOS (Para crear objetos fácilmente) ---
        public Tapas(String nombre, Double precio, String tipoTapas) {
            this.nombre = nombre;
            this.precio = precio;
            this.tipoTapas = tipoTapas;
        }


        // --- 3. GETTERS Y SETTERS (Autogenerar con Alt + Insert) ---
        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }
        public Double getPrecio() {
            return precio;
        }

        public void setPrecio(Double precio) {
            this.precio = precio;
        }

        public void setTipoTapas(String tipoTapas) {
            this.tipoTapas = tipoTapas;
        }

        public String getTipoTapas() {
            return tipoTapas;
        }

        }



