package com.example.tapas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TapasApplication {

    public static void main(String[] args) {
        SpringApplication.run(TapasApplication.class, args);
    }

}
