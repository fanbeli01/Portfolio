package com.example.tapas.controller;

import com.example.tapas.model.Tapas;
import com.example.tapas.repository.TapasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@RestController
@RequestMapping("/api/tapas")
public class TapasController {
    @Autowired
    private TapasRepository tapasRepository;

    @GetMapping
    public List<Tapas> obtenerTodos(@RequestParam(required = false) String tipo) {
        if (tipo == null || tipo.trim().isEmpty()) {
            return tapasRepository.findAll();
        }
        return tapasRepository.findByTipoTapasIgnoreCase(tipo.trim());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Tapas> obtenerUna(@PathVariable Long id) {
        return tapasRepository.findById(id)
                .map(tapa -> ResponseEntity.ok(tapa))
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Tapas> crear(@RequestBody Tapas tapa) {
        validar(tapa);
        // Un alta siempre genera su propio ID, nunca modifica otro registro.
        tapa.setId(null);
        return ResponseEntity.status(HttpStatus.CREATED).body(tapasRepository.save(tapa));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Tapas> actualizarTapa(@PathVariable Long id, @RequestBody Tapas detalles) {
        validar(detalles);
        return tapasRepository.findById(id)
                .map(tapa -> {
                    tapa.setNombre(detalles.getNombre());
                    tapa.setPrecio(detalles.getPrecio());
                    tapa.setTipoTapas(detalles.getTipoTapas());
                    return ResponseEntity.ok(tapasRepository.save(tapa));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (!tapasRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        tapasRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private void validar(Tapas tapa) {
        if (tapa.getNombre() == null || tapa.getNombre().trim().isEmpty()
                || tapa.getNombre().trim().length() > 80) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Nombre obligatorio, máximo 80 caracteres.");
        }
        if (tapa.getPrecio() == null || !Double.isFinite(tapa.getPrecio())
                || tapa.getPrecio() < 0.01 || tapa.getPrecio() > 1000) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Precio entre 0,01 y 1000 euros.");
        }
        if (tapa.getTipoTapas() == null
                || !(tapa.getTipoTapas().trim().equalsIgnoreCase("fria")
                || tapa.getTipoTapas().trim().equalsIgnoreCase("caliente"))) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Tipo permitido: fria o caliente.");
        }
        tapa.setNombre(tapa.getNombre().trim());
        tapa.setTipoTapas(tapa.getTipoTapas().trim().toLowerCase(java.util.Locale.ROOT));
    }
}
