package com.example.tapas.repository;

import com.example.tapas.model.Tapas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository


public interface TapasRepository extends JpaRepository<Tapas, Long> {
    List<Tapas> findByTipoTapasIgnoreCase(String tipoTapas);
}


