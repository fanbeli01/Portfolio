# Carta de tapas

Ejercicio académico con Java, Spring Boot, JPA y una pantalla sencilla de HTML, CSS y JavaScript. Conserva el modelo y la organización en controller/model/repository del original.

## Antes de empezar

Necesitas JDK 17 y acceso a Internet para que Maven descargue las dependencias. Se conserva la versión de Spring Boot 4.1.1 del pom.xml recibido; en este entorno no se ha podido resolver desde Maven Central por un fallo de DNS. La compilación y el arranque de Java quedan pendientes en tu equipo. Si Maven indica que la versión no existe (distinto de un error de conexión), revisa la versión utilizada en clase antes de cambiarla.

## Arranque fácil: perfil demo

Desde esta carpeta, en PowerShell:

```powershell
.\mvnw.cmd spring-boot:run "-Dspring-boot.run.profiles=demo"
```

En Linux/macOS:

```sh
sh mvnw spring-boot:run -Dspring-boot.run.profiles=demo
```

También puedes importar pom.xml como proyecto Maven en tu IDE y ejecutar TapasApplication con el argumento `--spring.profiles.active=demo`.

Después de que la aplicación arranque, abre http://localhost:8080 . La carta empieza vacía: añade tres tapas desde el formulario. El perfil demo utiliza H2 en memoria; se pierde todo al detener el programa. No requiere instalar SQL Server.

## Usar SQL Server

Sin el perfil demo se usa SQL Server. Crea una base de datos de prácticas llamada Tapas y configura estas variables en la ejecución del IDE:

- DB_URL: URL JDBC de tu servidor. Por ejemplo `jdbc:sqlserver://localhost:1433;databaseName=Tapas;encrypt=true;trustServerCertificate=true`.
- DB_USER: tu usuario de SQL Server.
- DB_PASSWORD: tu contraseña.

El puerto y la instancia deben coincidir con tu instalación. El ZIP original usaba SQLEXPRESS; puedes configurar su URL en DB_URL. No guardes credenciales reales en el repositorio. `trustServerCertificate=true` es una simplificación para desarrollo local. JPA mantiene las tablas con ddl-auto=update, como en el ejercicio original. No se ha comprobado la conexión a SQL Server en este entorno.

## API

| Método | Ruta | Resultado |
|---|---|---|
| GET | /api/tapas | Lista todas las tapas |
| GET | /api/tapas?tipo=fria | Filtra por tipo sin distinguir mayúsculas |
| GET | /api/tapas/{id} | Obtiene una tapa; 404 si no existe |
| POST | /api/tapas | Crea una tapa; responde 201 |
| PUT | /api/tapas/{id} | Cambia nombre, precio y tipo; 404 si no existe |
| DELETE | /api/tapas/{id} | Elimina; responde 204 o 404 |

Ejemplo de cuerpo JSON para POST o PUT:

```json
{"nombre":"Salmorejo","precio":3.5,"tipoTapas":"fria"}
```

Validaciones: nombre no vacío de hasta 80 caracteres, precio de 0,01 a 1000 y tipo `fria` o `caliente`. Un cuerpo inválido devuelve 400. Las altas descartan un ID enviado por el cliente para no sobrescribir otra tapa.

## Cómo se conecta la pantalla

1. Un evento de botón o formulario ejecuta una función de app.js.
2. `fetch` envía una petición a `/api/tapas`.
3. El controlador comprueba los datos y llama al repositorio.
4. JPA accede a la base de datos.
5. La pantalla recibe JSON y crea las tarjetas con `textContent`.

HTML define los elementos; CSS los coloca y colorea; JavaScript maneja eventos y peticiones. No se utiliza React ni otra biblioteca de interfaz.

## Límites

Aplicación local de prácticas, sin autenticación, autorización, pagos ni pedidos. No la expongas como gestor público: cualquier visitante podría modificar la carta. Se conserva Double para precio para no introducir otro concepto en este ejercicio; una aplicación comercial necesita tratar con más precisión los importes. No hay gestión de concurrencia. Un filtro desconocido simplemente devuelve una lista vacía.

## Pruebas

`mvnw.cmd test` (Windows) o `sh mvnw test` (Linux/macOS). La prueba de contexto usa el perfil demo. Consulta también PRUEBAS.md en la carpeta superior para conocer exactamente lo comprobado y lo pendiente.
