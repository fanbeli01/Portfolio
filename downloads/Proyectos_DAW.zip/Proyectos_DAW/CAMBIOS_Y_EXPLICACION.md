# Cambios y explicación para estudiar

Las referencias de línea corresponden a los archivos de ESTA entrega. Los ZIP recibidos se conservan sin modificar.

## Tienda/src/Entrada.java

Nueva clase pequeña: comparte un Scanner, lee líneas completas y repite la pregunta si la cantidad no es válida. Concepto nuevo: try/catch para tratar un dato que no se puede convertir a entero.

- `leerTexto`: línea 7.
- `leerCantidad`: línea 15.

## Tienda/src/TiendaGloria.java

Crea un único Entrada y lo pasa al menú. Se elimina un objeto Compras que se creaba pero no se utilizaba. Se controla el fin de entrada.

- `main`: línea 2.

## Tienda/src/AccionUsuario.java

Mantiene el switch y el bucle originales; añade catálogo y acepta opciones numéricas o texto normalizado.

- `AccionUsuario`: línea 8.
- `AccionUsuarioTienda`: línea 16.

## Tienda/src/Inventario.java

Añade un segundo HashMap con unidades compradas pendientes de devolver. Comprar resta stock y suma vendidas; devolver hace lo contrario. El catálogo recorre las claves.

- `registrarCompra`: línea 29.
- `registrarDevolucion`: línea 34.
- `mostrarCatalogo`: línea 39.

## Tienda/src/Compras.java

Usa Entrada, comprueba producto y stock, registra la compra y conserva el Ticket original.

- `comprar`: línea 12.

## Tienda/src/Devoluciones.java

Rechaza devoluciones superiores a las compras pendientes de esa sesión antes de cambiar los mapas.

- `devolver`: línea 10.

## Tapas/src/main/java/com/example/tapas/controller/TapasController.java

Completa las operaciones REST y valida los datos con condiciones sencillas. Se conserva el uso de map/orElse que ya estaba en el original. Actualizar ahora también guarda el tipo.

- `obtenerTodos`: línea 19.
- `obtenerUna`: línea 27.
- `crear`: línea 34.
- `actualizarTapa`: línea 42.
- `eliminar`: línea 55.
- `validar`: línea 63.

## Tapas/src/main/java/com/example/tapas/repository/TapasRepository.java

El nombre del método indica a Spring Data que filtre por tipo ignorando mayúsculas.

- `findByTipoTapasIgnoreCase`: línea 12.

## Tapas/src/main/resources/static/app.js

Archivo nuevo. fetch llama a la API; async/await espera la respuesta; los eventos reaccionan a botones y formulario. Se usan elementos y textContent para mostrar nombres como texto. numeroConsulta impide que una respuesta antigua reemplace al filtro actual.

- `llamarApi`: línea 19.
- `cargarTapas`: línea 35.
- `mostrarTarjeta`: línea 56.
- `limpiarFormulario`: línea 100.

## Otros cambios de configuración

- Se retiran Lombok/Slf4j y sus llamadas de Tienda: para este ejercicio de consola no hacen falta dependencias externas. Si en clase te piden registros, puedes conservar esa variante por separado.
- Tienda mantiene el Ticket y los precios enteros del original; se añade la unidad EUR al total.
- Tapas conserva la entidad Tapas, su Long para ID y Double para precio.
- `Tapas/pom.xml`: se añade H2 como dependencia runtime. No se cambia la versión de Spring del original.
- `Tapas/src/main/resources/application.properties`: se sustituyen credenciales incrustadas por variables de entorno.
- `application-demo.properties`: configuración nueva para una base de datos temporal.
- `TapasApplicationTests`: se activa demo para que la prueba no dependa de SQL Server.
- `static/index.html` y `static/styles.css`: pantalla nueva; puedes cambiar textos, colores y tamaños sin tocar Java.

## Preguntas que debes poder contestar

**¿Por qué un solo Scanner?** Porque todas las acciones leen de la misma entrada del teclado. Compartir un lector evita que varios lectores interfieran.

**¿Por qué nextLine y parseInt?** Se recoge la línea completa. Después se intenta convertir a entero y se controla el caso en que no sea válido.

**¿Qué almacena un HashMap?** Pares clave/valor: aquí el nombre del producto y una cantidad. No guarda automáticamente los datos en disco.

**¿Qué significa pasar un objeto al constructor?** Las clases reciben la misma instancia de Inventario. Por eso un cambio en compras se refleja al mostrar el catálogo.

**¿Qué diferencia hay entre entidad, repositorio y controlador?** La entidad describe los datos; el repositorio accede a la base de datos; el controlador atiende peticiones y valida.

**¿Por qué validar también en Java?** Porque una petición puede llegar sin pasar por el formulario del navegador.

**¿Qué es H2?** La base de datos del modo demo. En esta configuración está en memoria y desaparece al cerrar; SQL Server es la opción separada para guardar datos.

**¿Qué has añadido con ayuda?** Validación de entrada y devoluciones, operaciones que faltaban en la API, modo demo y pantalla. Conviene distinguir estas ampliaciones de tu base original.

## Orden de estudio

1. Tienda: menú → compra → inventario → ticket.
2. Entrada: leer texto, conversión a número y try/catch.
3. Devoluciones: dibuja en papel cómo cambian stock y vendidas.
4. Tapas: sigue primero GET y POST; después PUT, DELETE y validación.
5. Pantalla: entiende un único botón antes de leer todo app.js. Si async/await y fetch no los has estudiado, preséntalos como aprendizaje reciente.
