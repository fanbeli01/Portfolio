# Proyectos para un portfolio DAW

## Selección

| Proyecto recibido | Decisión | Motivo observado en el código |
|---|---|---|
| Tienda | Elegido | Compras, devoluciones, inventario, precios y tickets ya separados en clases. |
| Tapas | Elegido | Modelo JPA, repositorio y controlador REST con listado, alta y edición. |
| TiendaLibros | Reserva | Similar a Tienda, pero no calcula el importe de la compra ni emite ticket. |
| Floristeria | Reserva | El método reducirStock está vacío y main no llama al menú de compras. |
| CosasVarias | No mostrar todavía | Solo contiene el arranque de Spring y la prueba de contexto; no hay funcionalidad de negocio. |

Para este portfolio bastan dos proyectos distintos. No hace falta presentar tres variantes del mismo ejercicio.

## Qué contiene esta entrega

- Tienda: conserva el ejercicio de consola y sus clases principales. Corrige la entrada de datos, añade catálogo y controla las devoluciones de la sesión.
- Tapas: conserva entidad, repositorio y controlador. Añade consulta individual, borrado, filtro y validaciones. Incluye una pequeña pantalla conectada a la API y un perfil demo con H2.
- Cada carpeta tiene instrucciones para ejecutarla y sus límites.
- CAMBIOS_Y_EXPLICACION.md identifica archivos, métodos y líneas de esta versión, además de los conceptos nuevos.
- PRUEBAS.md recoge las comprobaciones realizadas y las pendientes.

## Orden recomendado

1. Empieza por Tienda. Ejecuta ejecutar.bat en Windows con un JDK instalado, o abre src en tu IDE y ejecuta TiendaGloria.
2. Lee Entrada y sigue una compra desde AccionUsuario hasta Inventario y Ticket.
3. Prueba una compra y una devolución; explica en voz alta cómo cambian los dos mapas.
4. Abre el pom.xml de Tapas como proyecto Maven. Sigue su README para arrancar el perfil demo.
5. Añade una tapa, cambia su tipo, filtra y elimínala. Comprueba que la pantalla llama al backend.
6. Cuando ambas funcionen en tu ordenador, toma capturas reales y añade los enlaces a los repositorios al portfolio.

## Cómo presentarlos

**Tienda de Gloria — gestión por consola.** Proyecto académico en Java para practicar clases, constructores y HashMap mediante un catálogo, compras, devoluciones y tickets. Datos en memoria durante la ejecución.

**Carta de tapas — primera API con Spring.** Proyecto académico para gestionar tapas con Java, Spring Boot y JPA. Incluye una interfaz sencilla para consultar, añadir, editar, filtrar y eliminar registros. Configuración para SQL Server y modo demo con H2.

No presentes estos ejercicios como aplicaciones comerciales ni como experiencia laboral. La pantalla de Tapas y las ampliaciones se han preparado con ayuda: revísalas antes de atribuirte su dominio. Puedes explicar que el proyecto partió de un ejercicio propio y que lo mejoraste con apoyo.

## Parte visual del futuro portfolio

Cada proyecto puede ocupar una tarjeta con una captura real, descripción breve, tecnologías y botón al código. Para Tienda, captura el catálogo y un ticket; para Tapas, captura la carta con tres tapas y el formulario. Usa la interfaz desde localhost, no abriendo el HTML con doble clic.

Esta entrega prepara los proyectos; no publica todavía una web de portfolio ni crea repositorios externos.
