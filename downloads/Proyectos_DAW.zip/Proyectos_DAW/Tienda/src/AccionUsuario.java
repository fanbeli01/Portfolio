public class AccionUsuario {
    private Inventario inventario;
    private PrecioProductos precios;
    private Compras compras;
    private Devoluciones devoluciones;
    private Entrada entrada;

    public AccionUsuario(Inventario inventario, PrecioProductos precios, Entrada entrada) {
        this.inventario = inventario;
        this.precios = precios;
        this.entrada = entrada;
        compras = new Compras(inventario, precios, entrada);
        devoluciones = new Devoluciones(inventario, entrada);
    }

    public void AccionUsuarioTienda() {
        boolean continuar = true;
        while (continuar) {
            System.out.println("\nLA TIENDA DE GLORIA");
            System.out.println("1. Catálogo | 2. Comprar | 3. Devolver | 4. Salir");
            String opcion = entrada.leerTexto("Elige una opción: ");
            switch (opcion) {
                case "1":
                case "catalogo":
                    inventario.mostrarCatalogo(precios);
                    break;
                case "2":
                case "comprar":
                    compras.comprar();
                    break;
                case "3":
                case "devolver":
                    devoluciones.devolver();
                    break;
                case "4":
                case "salir":
                    continuar = false;
                    break;
                default:
                    System.out.println("Opción no reconocida.");
            }
        }
        System.out.println("Gracias por visitar La Tienda de Gloria.");
    }
}
