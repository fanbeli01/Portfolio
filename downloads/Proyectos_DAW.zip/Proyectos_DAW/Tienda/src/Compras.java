public class Compras {
    private Inventario inventario;
    private PrecioProductos precioProductos;
    private Entrada entrada;

    public Compras(Inventario inventario, PrecioProductos precios, Entrada entrada) {
        this.inventario = inventario;
        this.precioProductos = precios;
        this.entrada = entrada;
    }

    public void comprar() {
        String producto = entrada.leerTexto("Producto (falda, pantalon, bolso): ");
        if (!inventario.quedaProducto(producto)) {
            System.out.println("El producto no existe.");
            return;
        }
        int unidades = entrada.leerCantidad();
        if (unidades > inventario.obtenerStock(producto)) {
            System.out.println("Stock insuficiente. Quedan: " + inventario.obtenerStock(producto));
            return;
        }
        inventario.registrarCompra(producto, unidades);
        Ticket ticket = new Ticket(unidades, producto, precioProductos.obtenerPrecio(producto));
        ticket.mostrarTicket();
    }
}
