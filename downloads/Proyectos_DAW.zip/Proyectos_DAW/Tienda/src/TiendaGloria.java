public class TiendaGloria {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();
        PrecioProductos precios = new PrecioProductos();
        Entrada entrada = new Entrada();
        AccionUsuario menu = new AccionUsuario(inventario, precios, entrada);
        try {
            menu.AccionUsuarioTienda();
        } catch (java.util.NoSuchElementException error) {
            System.out.println("Fin de la entrada. Hasta pronto.");
        }
    }
}
