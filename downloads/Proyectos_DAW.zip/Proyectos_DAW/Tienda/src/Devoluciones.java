public class Devoluciones {
    private Inventario inventario;
    private Entrada entrada;

    public Devoluciones(Inventario inventario, Entrada entrada) {
        this.inventario = inventario;
        this.entrada = entrada;
    }

    public void devolver() {
        String producto = entrada.leerTexto("Producto a devolver: ");
        if (!inventario.quedaProducto(producto)) {
            System.out.println("El producto no existe.");
            return;
        }
        int unidades = entrada.leerCantidad();
        if (unidades > inventario.obtenerVendidas(producto)) {
            System.out.println("Solo puedes devolver unidades compradas en esta sesión. Disponibles: "
                    + inventario.obtenerVendidas(producto));
            return;
        }
        inventario.registrarDevolucion(producto, unidades);
        System.out.println("Devolución aceptada. Stock: " + inventario.obtenerStock(producto));
    }
}
