import java.util.Scanner;

// Un único lector para toda la aplicación.
public class Entrada {
    private Scanner sc = new Scanner(System.in);

    public String leerTexto(String mensaje) {
        System.out.print(mensaje);
        if (!sc.hasNextLine()) {
            throw new java.util.NoSuchElementException("Entrada finalizada");
        }
        return sc.nextLine().trim().toLowerCase(java.util.Locale.ROOT);
    }

    public int leerCantidad() {
        while (true) {
            String texto = leerTexto("Unidades (número entero positivo): ");
            try {
                int cantidad = Integer.parseInt(texto);
                if (cantidad > 0) {
                    return cantidad;
                }
            } catch (NumberFormatException error) {
                // Volvemos a pedir el dato si no es un número entero.
            }
            System.out.println("Introduce un entero mayor que cero.");
        }
    }
}
