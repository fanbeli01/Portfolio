public class Ticket {

       private static int contadorTickets = 0;
        private int id_ticket;
        private int unidades;
        private String tipoPrenda;
        private int precioProducto;


        public Ticket(int unidades, String tipoPrenda, int precioProducto) {
            contadorTickets++;
            this.id_ticket = contadorTickets;
            this.unidades = unidades;
            this.tipoPrenda = tipoPrenda;
            this.precioProducto = precioProducto;
        }

        public void mostrarTicket(){

            System.out.println("_______TICKET DE LA TIENDA DE GLORIA_______");

            System.out.println(" Ticket nº: " + id_ticket);
            System.out.println(" Tipo de prenda : " + tipoPrenda);
            System.out.println(" Unidades : " + unidades);
            System.out.println("Precio: " + precioProducto +"€");
            System.out.println("TOTAL A PAGAR: " + unidades * precioProducto + " EUR");


        }
    }

