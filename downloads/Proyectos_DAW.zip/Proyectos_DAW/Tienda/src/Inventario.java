import java.util.HashMap;

public class Inventario {
    private HashMap<String, Integer> productoDisponible = new HashMap<>();
    // Compras pendientes de devolver durante esta ejecución.
    private HashMap<String, Integer> unidadesVendidas = new HashMap<>();

    public Inventario() {
        productoDisponible.put("falda", 20);
        productoDisponible.put("pantalon", 20);
        productoDisponible.put("bolso", 10);
        unidadesVendidas.put("falda", 0);
        unidadesVendidas.put("pantalon", 0);
        unidadesVendidas.put("bolso", 0);
    }

    public boolean quedaProducto(String producto) {
        return productoDisponible.containsKey(producto);
    }

    public int obtenerStock(String producto) {
        return productoDisponible.get(producto);
    }

    public int obtenerVendidas(String producto) {
        return unidadesVendidas.get(producto);
    }

    public void registrarCompra(String producto, int unidades) {
        productoDisponible.put(producto, obtenerStock(producto) - unidades);
        unidadesVendidas.put(producto, obtenerVendidas(producto) + unidades);
    }

    public void registrarDevolucion(String producto, int unidades) {
        productoDisponible.put(producto, obtenerStock(producto) + unidades);
        unidadesVendidas.put(producto, obtenerVendidas(producto) - unidades);
    }

    public void mostrarCatalogo(PrecioProductos precios) {
        System.out.println("PRODUCTO       PRECIO       STOCK");
        for (String producto : productoDisponible.keySet()) {
            System.out.printf("%-14s %3d EUR      %d%n", producto,
                    precios.obtenerPrecio(producto), obtenerStock(producto));
        }
    }
}
