import java.util.HashMap;

public class PrecioProductos {
    private HashMap<String, Integer> precioProductos = new HashMap<>();

    public PrecioProductos() {
        precioProductos.put("falda", 5);
        precioProductos.put("pantalon", 10);
        precioProductos.put("bolso", 8);
    }

    public int obtenerPrecio(String producto) {
        return precioProductos.get(producto);
    }
}
