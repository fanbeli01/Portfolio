# Tienda de Gloria

Ejercicio académico de Java por consola. Se mantienen clases, constructores, condiciones, switch, bucles y HashMap del proyecto original.

## Requisitos y ejecución

JDK 17 o posterior. No necesita Maven, Lombok ni base de datos.

Windows: ejecuta `ejecutar.bat`, o importa `src` en el IDE y ejecuta `TiendaGloria.main`.

Terminal, desde esta carpeta:

```sh
mkdir out
javac -encoding UTF-8 -d out src/*.java
java -cp out TiendaGloria
```

En Linux/macOS también puedes usar `sh ejecutar.sh`.

## Funciones

- Consultar catálogo, precios y existencias.
- Comprar un producto y generar ticket numerado.
- Rechazar cantidades cero, negativas, texto y compras sin stock suficiente.
- Devolver unidades compradas durante esta ejecución, sin superar la cantidad pendiente.
- Aceptar opciones en mayúsculas/minúsculas y con espacios alrededor.

## Prueba rápida

1. Consulta el catálogo: falda 20, pantalon 20, bolso 10.
2. Compra 2 faldas. Ticket: 10 EUR; stock: 18.
3. Devuelve 1 falda. Stock: 19.
4. Intenta devolver 2 faldas más: debe rechazarse, porque solo queda 1 pendiente de devolución.
5. Compra un bolso introduciendo primero `hola`, después `0` y finalmente `1`: vuelve a pedir las entradas incorrectas.

## Límites deliberados

Los datos y el contador de tickets se reinician al cerrar. No hay usuarios ni cobros reales; las devoluciones se controlan por producto dentro de una sesión, no por ticket. Los precios son enteros en euros, como en el ejercicio original. `quedaProducto` comprueba que el nombre existe; la disponibilidad se valida después comparando la cantidad con el stock.

## Qué explicar

`AccionUsuario` dirige el menú; `Entrada` lee y valida; `Compras` y `Devoluciones` comprueban la operación; `Inventario` guarda las cantidades; `PrecioProductos` guarda los precios; `Ticket` imprime el resultado.
