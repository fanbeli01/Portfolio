@echo off
cd /d "%~dp0"
if not exist out mkdir out
javac -encoding UTF-8 -d out src\*.java
if errorlevel 1 (
  echo Revisa que tienes un JDK instalado y configurado.
  pause
  exit /b 1
)
java -cp out TiendaGloria
pause
