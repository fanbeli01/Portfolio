# Comprobaciones de esta entrega

## Ejecutadas y correctas

- Compilación de todas las clases de Tienda con Java 17, sin dependencias externas.
- Compra de dos faldas: ticket de 10 EUR; devolución de una: stock 19.
- Entrada de letras, cero, negativos y un entero fuera de rango: se vuelve a pedir la cantidad.
- Compra superior al stock: rechazada.
- Producto inexistente: rechazado.
- Devolución sin compras previas: rechazada.
- Compra de todo el stock de bolsos: siguiente compra rechazada; devolución completa repone el stock y una devolución adicional se rechaza.
- Fin de entrada durante una operación: cierre sin traza de error.
- Sintaxis de app.js comprobada con `node --check`.

## No verificadas en este entorno

- Compilación y prueba de contexto de Tapas: se intentó `sh mvnw test`, pero Maven Central no resolvió por DNS al descargar el parent Spring Boot 4.1.1 del proyecto original. Esto no demuestra ni descarta otros errores de compilación o ejecución.
- API, H2, SQL Server y conexión real navegador/API: pendientes del arranque en tu ordenador.
- Renderizado y comportamiento en navegador: no se pudo instalar Chromium en este entorno. HTML y CSS revisados como código; no se ha validado visualmente su resultado.
- Ejecutar.bat y mvnw.cmd en Windows: pendientes de tu equipo. Las clases Java de Tienda sí se han ejecutado aquí.

## Lista de comprobación en tu equipo

1. Arranca Tapas con perfil demo y abre http://localhost:8080.
2. Añade Salmorejo, 3,50, fria. Comprueba que aparece y continúa tras recargar.
3. Edita nombre, precio y tipo. Comprueba todos los cambios.
4. Filtra por fría/caliente y vuelve a Todas.
5. Cancela una edición: el formulario debe quedar en modo alta.
6. Elimina una tapa confirmando y comprueba que desaparece.
7. Desde un cliente HTTP, prueba nombre vacío, precio cero y tipo desconocido: deben devolver 400.
8. Consulta, modifica y borra un ID inexistente: deben devolver 404 (en PUT usa un cuerpo válido).
9. Reinicia la aplicación demo: la carta debe quedar vacía.
10. Repite con SQL Server, sin demo: los datos deben mantenerse al reiniciar.
11. Reduce la ventana a móvil: comprueba legibilidad, botones y ausencia de desplazamiento horizontal.

No presentes Tapas como comprobado hasta completar estos pasos. Si aparece un error, guarda el mensaje completo del arranque o la respuesta HTTP.
